Tornado Terrorizer REPLACES: Necromancer (2576060529)

albedo.vtf replaces "2576060529_albedo.vtf"
base.vtf replaces "2576060529.vtf"
base_blu.vtf replaces "2576060529_blue.vtf"
brass.vtf replaces "2576060529_paper.vtf"
emblem_l.vtf replaces "2576060529_eye_angry_l.vtf"
emblem_r.vtf replaces "2576060529_eye_angry_r.vtf"
metal_base.vtf replaces "2576060529_metal_base.vtf"
metal_gradient.vtf replaces "2576060529_metal_gradient.vtf"
metal_gradient_blu.vtf replaces "2576060529_metal_gradient_blue.vtf"


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Please apply the following parameters!

Team Variant: 1 (true)
Custom Wear: 1 (true)
Albedo Shine/Shading: 1 (true)
Texture Rotation: 1 (true)
Sample Gradient: 1 (true)